package dao;

import java.sql.SQLException;
import java.util.List;

import entity.Loan;
import exception.InvalidLoanException;

public interface ILoanDAO {
	
	public int applyLoan(Loan loan) throws SQLException,ClassNotFoundException,InvalidLoanException;
    public double calculateInterest(int loanId) throws SQLException,ClassNotFoundException,InvalidLoanException;
    public String loanStatus(int loanId) throws SQLException,ClassNotFoundException,InvalidLoanException;
    public double calculateEMI(int loanId) throws SQLException,ClassNotFoundException,InvalidLoanException;
    public void loanRepayment(int loanId, double amount) throws SQLException,ClassNotFoundException,InvalidLoanException;
    public List<Loan> getAllLoan() throws SQLException,ClassNotFoundException,InvalidLoanException;
    public Loan getLoanById(int loanId) throws SQLException,ClassNotFoundException,InvalidLoanException;

}
