package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.Customer;
import entity.Loan;
import exception.InvalidLoanException;
import util.DBUtil;

public class LoanDAOImpl implements ILoanDAO {
	
	private static Connection connection;

	@Override
	public int applyLoan(Loan loan) throws SQLException, ClassNotFoundException {
				
				
		connection = DBUtil.createConnection();
		String query = "INSERT INTO loan(customer_id,principal_amount,interest_rate,loan_term,loan_type,loan_status) VALUES(?,?,?,?,?,?)";
		        
        PreparedStatement prepareStUser = connection.prepareStatement(query);
		
		prepareStUser.setInt(1,loan.getCustomer().getCustomerId());
		prepareStUser.setInt(2,loan.getPrincipalAmount());
		prepareStUser.setInt(3,loan.getInterestRate());
		prepareStUser.setInt(4,loan.getLoanTerm());
		prepareStUser.setString(5,loan.getLoanType());
		prepareStUser.setString(6,loan.getLoanStatus());
		
		int result = prepareStUser.executeUpdate();
		DBUtil.closeConnection();
		return result;

	}

	@Override
	public double calculateInterest(int loanId) throws SQLException, ClassNotFoundException, InvalidLoanException {
		
		connection = DBUtil.createConnection();
		
        double ans = 0;
        
        String query = "SELECT * FROM loan WHERE loan_id = ?";
		
		PreparedStatement prepareStloan = connection.prepareStatement(query);

		prepareStloan.setInt(1, loanId);

		ResultSet rs = prepareStloan.executeQuery();

		while (rs.next()) {
			
			int principal_amount = rs.getInt(3);
			int interest_rate = rs.getInt(4);
			int loan_term = rs.getInt(5);
			
			ans = (principal_amount*interest_rate*loan_term)/12;
	
		}
		
		DBUtil.closeConnection();

		return ans;
	}

	@Override
	public String loanStatus(int loanId) throws SQLException, ClassNotFoundException, InvalidLoanException {

		String status = null;
		int creditScore = 0;
		
		connection = DBUtil.createConnection();
		
		String query = "SELECT credit_score FROM customer WHERE customer_id = "
		        + "(SELECT customer_id FROM loan WHERE loan_id = ?)";
		        
		PreparedStatement prepareStloan = connection.prepareStatement(query);
		prepareStloan.setInt(1, loanId); 

		ResultSet rsLoan = prepareStloan.executeQuery();
		
		while(rsLoan.next()) {
			creditScore = rsLoan.getInt(1);
		}
		
		if(creditScore>650) {
			status = "Loan approved as your credit score is more then 650";
		}
		else {
			status = "Loan not approved as your credit score is less then 650";
		}
		
		return status;

	}

	@Override
	public double calculateEMI(int loanId) throws SQLException, ClassNotFoundException, InvalidLoanException {
   
		connection = DBUtil.createConnection();
		
        double emi = 0;
        
        String query = "SELECT * FROM loan WHERE loan_id = ?";
		
		PreparedStatement prepareStloan = connection.prepareStatement(query);

		prepareStloan.setInt(1, loanId);

		ResultSet rs = prepareStloan.executeQuery();

		while (rs.next()) {
			
			int principal_amount = rs.getInt(3);
			int interest_rate = rs.getInt(4);
			int monthly_intrest_rate = interest_rate/12;
			int loan_term = rs.getInt(5);
			
			emi = (principal_amount*monthly_intrest_rate*Math.pow((1+monthly_intrest_rate), loan_term))/Math.pow((1+monthly_intrest_rate), loan_term-1);
		
		}
		
		DBUtil.closeConnection();

		return emi;
	}

	@Override
	public void loanRepayment(int loanId, double amount)
			throws SQLException, ClassNotFoundException, InvalidLoanException {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Loan> getAllLoan() throws SQLException, ClassNotFoundException ,InvalidLoanException{
		
		List<Loan>loans = new ArrayList<>();
		
		connection = DBUtil.createConnection();
		
		Loan loan = null;
        int customer_id=0;
        int loanId = 0;
        int principal_amount=0;
        int interest_rate=0;
        int loan_term=0;
        String loan_type=null;
        String loan_status=null;
        Customer customer=null;
        
        String query = "SELECT * FROM loan";
        
        PreparedStatement prepareStLoan = connection.prepareStatement(query);
		
		ResultSet rsLoan = prepareStLoan.executeQuery(); 
		
        while (rsLoan.next()) {
			
        	loanId = rsLoan.getInt("loan_id");
			customer_id = rsLoan.getInt("customer_id");
			principal_amount = rsLoan.getInt("principal_amount");
			interest_rate = rsLoan.getInt("interest_rate");
			loan_term = rsLoan.getInt("loan_term");
			loan_type = rsLoan.getString("loan_type");
			loan_status=rsLoan.getString("loan_status");

			customer = new Customer();
			customer.setCustomerId(customer_id);

			loan = new Loan(loanId,customer,principal_amount,interest_rate,loan_term,loan_type,loan_status);
			loans.add(loan);
		
		}
		
		DBUtil.closeConnection();

		if (loan == null) {
			throw new InvalidLoanException("No loan Found or invalid entry for fetching loan");
		}

		return loans;
		
	}

	@Override
	public Loan getLoanById(int loanId) throws SQLException, ClassNotFoundException, InvalidLoanException {

		Loan loan = null;
        int customer_id=0;
        int principal_amount=0;
        int interest_rate=0;
        int loan_term=0;
        String loan_type=null;
        String loan_status=null;
        Customer customer=null;
		
		connection = DBUtil.createConnection();
		
		String query = "SELECT * FROM loan l JOIN Customer c "
				+ "USING(customer_id) WHERE loan_id = ?";
		
		PreparedStatement prepareStloan = connection.prepareStatement(query);

		prepareStloan.setInt(1, loanId);

		ResultSet rsLoan = prepareStloan.executeQuery();

		while (rsLoan.next()) {
			
			customer_id = rsLoan.getInt("customer_id");
			principal_amount = rsLoan.getInt("principal_amount");
			interest_rate = rsLoan.getInt("interest_rate");
			loan_term = rsLoan.getInt("loan_term");
			loan_type = rsLoan.getString("loan_type");
			loan_status=rsLoan.getString("loan_status");

			customer = new Customer();
			customer.setCustomerId(customer_id);

			loan = new Loan(loanId,customer,principal_amount,interest_rate,loan_term,loan_type,loan_status);
		
		}
		
		DBUtil.closeConnection();

		if (loan == null) {
			throw new InvalidLoanException("No loan Found or invalid entry for fetching loan");
		}

		return loan;
	}

}