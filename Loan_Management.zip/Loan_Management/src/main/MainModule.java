package main;

import java.util.List;
import java.util.Scanner;

import entity.Customer;
import entity.Loan;
import services.ILoanService;
import services.LoanServiceImpl;

public class MainModule {
	
	public static void main(String []args) { 
		
		ILoanService iLoanService = new LoanServiceImpl();
		
		Loan loan = null;
		Customer customer = null;
			
        int choice = -1;
		
		Scanner scInput = new Scanner(System.in);
		
		while(choice!=0) {
			
			System.out.println("Loan Management System Menu:");
	        System.out.println("1. Apply Loan");
	        System.out.println("2. Get All Loans");
	        System.out.println("3. Get Loan by ID");
	        System.out.println("4. Calculate Intrest");
	        System.out.println("5. Loan Status");
	        System.out.println("6. Calculate EMI");
	        System.out.println("7. Loan Repayment");
	        System.out.println("8. Exit");
			
			choice = scInput.nextInt();
			
			switch(choice) {
			
			case 1:
				
				System.out.print("Please enter your coustemer id ");
            	int customerId = scInput.nextInt();
            	
            	System.out.print("Please enter your principal amount ");
            	int principal = scInput.nextInt();
            	
            	System.out.println("plaese select your loan type: ");
            	System.out.println("1. Home Loan (intrest rate - 9%)");
            	System.out.println("2. Car Loan (intrest rate - 12%)");
            	
            	int choice2 = scInput.nextInt();
            	
            	String loanType ="";
            	int interest = 0;
            	
            	if(choice2 == 1) {
            		loanType = "homeLoan";
            		interest = 9;
            	}else if(choice2 == 2) {
            		loanType = "carLoan";
            		interest = 12;
            	}
            	System.out.println("Enter loanterm in months");
            	int loanTerm = scInput.nextInt();
            	
            	System.out.println("Enter loan status");
            	String loanStatus = scInput.nextLine();
            	
            	Customer c = new Customer();
            	c.setCustomerId(customerId);
            	Loan l1 = new Loan(c,principal,interest,loanTerm,loanType,loanStatus);
            	
            	int success = 0;
                success = iLoanService.applyLoan(l1);
              	
            	if(success == 1) {
            		System.out.println("Loan Applied Successfully");
            	}
            	break;
			               
            case 2:
            	
                List<Loan> loanList = null;
                
                loanList = iLoanService.getAllLoan();
                
                System.out.println("Following are the Loans");
				for(Loan loan1:loanList) {
					System.out.println(loan1);
				}                
				break;
                
            case 3:
            	
                System.out.print("Enter loan ID: ");
                int loanId1 = scInput.nextInt();
                
                loan = iLoanService.getLoanById(loanId1);
                
                if(loan == null) {
					System.out.println("No Loan Found");
				}else {
					System.out.println(loan);
				}
;                
                break;
                
            case 4:
            	
            	System.out.print("Enter loan ID: ");
                int loanId2 = scInput.nextInt();
                
                double ans = 0;
                
                ans = iLoanService.calculateInterest(loanId2);
                               
			    System.out.println("Interest : "+ans);                
                break;
            	
            case 5:
            	System.out.print("Enter loan ID: ");
                int loanId3 = scInput.nextInt();
                
                String status = iLoanService.loanStatus(loanId3);
                
                System.out.println("Loan Status : "+status);
                break;
               
            case 6:
            	
            	System.out.print("Enter loan ID: ");
                int loanId4 = scInput.nextInt();
                
                double emi = 0;
                
                ans = iLoanService.calculateInterest(loanId4);
                               
			    System.out.println("EMI : "+emi);                
                break;
                
            case 7:
            	System.out.print("Enter Loan ID: ");
                int loanId = new Scanner(System.in).nextInt();

                System.out.print("Enter Repayment Amount: ");
                double amount = new Scanner(System.in).nextDouble();
                
                iLoanService.loanRepayment(loanId, amount);
                
            	break;
                
            default:
                System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
	}
}
