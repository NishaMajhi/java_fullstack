package services;

import java.util.List;

import entity.Loan;

public interface ILoanService {
	
	public int applyLoan(Loan loan);
    public double calculateInterest(int loanId);
    public String loanStatus(int loanId);
    public double calculateEMI(int loanId);
    public void loanRepayment(int loanId, double amount);
    public List<Loan> getAllLoan();
    public  Loan getLoanById(int loanId);

}
