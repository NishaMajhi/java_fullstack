package services;

import java.sql.SQLException;
import java.util.List;

import dao.ILoanDAO;
import dao.LoanDAOImpl;
import entity.Loan;
import exception.InvalidLoanException;

public class LoanServiceImpl implements ILoanService {
	
	private ILoanDAO iloandao;
	
	public LoanServiceImpl() {
		super();
		iloandao = new LoanDAOImpl();
	}
	

	@Override
	public int applyLoan(Loan loan) {
		
		int row = 0;
		
		try {
			row  = iloandao.applyLoan(loan);
		}
		catch(SQLException s) {
			System.out.println("Error in Query");
		}
        catch(ClassNotFoundException cnfe) {
     	    System.out.println("Looks like JDBC driver is not loaded");
        }
        catch(InvalidLoanException i) {
     	   System.out.println("Loan not Found");
        }
		
		return row;
						
	}

	@Override
	public double calculateInterest(int loanId) {

     double ans = 0;
     try {
			ans  = iloandao.calculateInterest(loanId);
		}
		catch(SQLException s) {
			System.out.println("Error in Query");
		}
     catch(ClassNotFoundException cnfe) {
     	System.out.println("Looks like JDBC driver is not loaded");
     }
     catch(InvalidLoanException i) {
     	System.out.println("Loan not Found");
     }
     
     return ans;
   }

	@Override
	public String loanStatus(int loanId) {
		
		String status = null;
		try {
			status = iloandao.loanStatus(loanId);
		}
		catch(SQLException s) {
			System.out.println("Error in Query");
		}
        catch(ClassNotFoundException cnfe) {
        	System.out.println("Looks like JDBC driver is not loaded");
        }
        catch(InvalidLoanException i) {
        	System.out.println("Loan not Found");
        }
		
		return status;

	}

	@Override
	public double calculateEMI(int loanId) {
		double ans = 0;
	     try {
				ans  = iloandao.calculateInterest(loanId);
			}
			catch(SQLException s) {
				System.out.println("Error in Query");
			}
	     catch(ClassNotFoundException cnfe) {
	     	System.out.println("Looks like JDBC driver is not loaded");
	     }
	     catch(InvalidLoanException i) {
	     	System.out.println("Loan not Found");
	     }
	     
	     return ans;
	}

	@Override
	public void loanRepayment(int loanId, double amount) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Loan> getAllLoan() {
		
		List<Loan> loans = null;
		try {
			loans  = iloandao.getAllLoan();
		}
		catch(SQLException s) {
			System.out.println("Error in Query");
		}
        catch(ClassNotFoundException cnfe) {
        	System.out.println("Looks like JDBC driver is not loaded");
        }
        catch(InvalidLoanException i) {
        	System.out.println("Loan not Found");
        }
		return loans;
	}

	
	@Override
	public Loan getLoanById(int loanId) {

		Loan loan = null;

        try {
			loan  = iloandao.getLoanById(loanId);
		}
		catch(SQLException s) {
			System.out.println("Error in Query");
		}
        catch(ClassNotFoundException cnfe) {
        	System.out.println("Looks like JDBC driver is not loaded");
        }
        catch(InvalidLoanException i) {
        	System.out.println("Loan not Found");
        }
        
		return loan;

	}

}
